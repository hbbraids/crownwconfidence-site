import WebsiteStarter from './WebsiteStarter.jsx'

export default function App() {
  return <WebsiteStarter />
}
