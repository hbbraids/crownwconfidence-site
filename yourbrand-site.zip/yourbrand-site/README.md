# YourBrand Site (Vite + React + Tailwind)

## Quick Start
1) Install Node.js (LTS) from nodejs.org
2) In this folder: `npm install`
3) Run: `npm run dev` and open the shown URL

## Deploy (Vercel)
- Create a GitHub repo and push this folder
- Import the repo in Vercel (New Project → Import)
- Click Deploy (defaults work)
